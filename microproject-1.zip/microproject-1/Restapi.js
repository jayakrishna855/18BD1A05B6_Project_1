const express=require('express');
const app=express();
let server=require('./server');
let middleware=require('./middleware');

const bodyParser=require('body-parser');
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

var MongoClient =require('mongodb').MongoClient;
var url ="mongodb://localhost:27017/";

const mydb='hospitalInventory';
let db;

MongoClient.connect(url,{useUnifiedTopology:true},function(err,client){
    if(err) return console.log(err);
    db=client.db(mydb);
    console.log('MongoDb connected ');

    console.log(`Database: ${mydb}`);

});


// Fetching Hospital details
app.get('/hospitaldetails',middleware.checkToken,function(req,res){
    console.log("Getting Hospital details");
    var data=db.collection('hospital').find().toArray(function(err,result){
    if(err) return err;
    console.log(result);
    return res.json(result);
    
    })
    ;
});


//Fetching Ventilator details
app.get('/Ventilatordetails',middleware.checkToken,function(req,res){
    console.log("Getting Ventilators details");
    var data=db.collection('ventilator').find().toArray(function(err,result){
    if(err) return err;
    console.log(result);
    return res.json(result);
    
    })
    ;
});


//Fetching Hospital by name
app.post('/GetHospitalbyname',middleware.checkToken,function(req,res){
    var name=req.query.name;
    console.log(name);
    db.collection('hospital').find({"hospital_name":new RegExp(name,'i')}).toArray().then(result=> res.json(result)
    );
    });


//Fetching Ventilator by status
app.post('/GetVentilatorbystatus',middleware.checkToken,function(req,res){
    var status=req.body.status;
    console.log(status);
    db.collection('ventilator').find({"status":status}).toArray().then(result=> res.json(result));
    });  


//Updating Ventilator details
app.put('/updateventilator',middleware.checkToken,function(req,res){
    var vid=req.body.ventilator_Id;
    console.log(vid);
    var newdata=req.body.status;
    db.collection('ventilator').updateOne({"ventilator_Id":vid},{$set:{"status":newdata}},function(err,result){
        res.json("1 document updated");
        if(err) return err;
    });
});


//Adding Ventilator
app.post('/AddVentilator',middleware.checkToken,function(req,res){
    var hd=req.body.hid;
    var vid=req.body.ventilator_Id;
    var status=req.body.status;
    var hn=req.body.hospital_name;
    db.collection('ventilator').insertOne({"hid":hd,"ventilator_Id":vid,"status":status,"hospital name":hn},function(err,result){
    res.json("1 document added");
    if(err) return err;
});
    
});

//Deleting Ventilator by its Id
app.delete('/DeleteVentilator',middleware.checkToken,function(req,res){
    var vid=req.body.vid;
    db.collection('ventilator').deleteOne({"ventilator_Id":vid},function(req,result){
        res.json("1 document deleted");
        if(err) return err;
    });

});





app.listen(3000);