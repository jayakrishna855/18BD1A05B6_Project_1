const express=require('express');
const bodyParser =require('body-parser');

let jwt=require('jsonwebtoken');

let config=require('./config.js');
let middleware=require('./middleware.js');

let app =require('./Restapi.js');

class HandleGenerator{
    login(req,res){
        let username=req.body.username;
        let password=req.body.password;
    

    let myusername='jk';
    let mypassword='abcd';
    if(username && password){
        if(username===myusername && password===mypassword){
            let token=jwt.sign({username:username},
                config.secret,{
                    expiresIn:'24h'
                });
                res.json({
                    success:true,
                    message:'Authentication successful',
                    token:token
                });

        }
        else{
            res.json({
                success:false,
                message:'Incorrect username or password'
            });
        }
    

    }
    else{
        res.json({
            sucess:false,
            message:'Authentication failed! Please check the request'
        });
    }
    }
    index(req,res){
        res.json({
            sucess:true,
            message:'Token verified'
        });
    }


}

//starting of server
function main(){
    let app=express();
    let handers =new HandleGenerator();
    //const port=process.env.PORT || 8000;
    app.use(bodyParser.urlencoded({
        extended:true
    }));
    app.use(bodyParser.json());

    app.post('/login',handers.login);// generates the token
    app.get('/',middleware.checkToken,handers.index);
    //verifies the token
    app.listen(300,()=>console.log('Server is listening at port 300'));
    
}
main();