module.exports={
    secret:'kmitDevelopers'
};